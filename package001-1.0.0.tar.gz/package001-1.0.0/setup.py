from setuptools import setup, find_packages
setup(name="package001",
version="1.0.0",
Description="Add",
author="Puja",
packages=["package001"],
install_requires=[])
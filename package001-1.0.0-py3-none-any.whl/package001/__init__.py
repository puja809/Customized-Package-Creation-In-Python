def add(a, b):
    return f"The sum is {a + b}"